# debugger.py


def debugger(file_out: str):
    print ("debugger {file_out}")
